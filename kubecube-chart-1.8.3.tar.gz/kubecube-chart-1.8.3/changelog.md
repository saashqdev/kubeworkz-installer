# v1.8.3

## Feature
- replace image pin to docker hub

# v1.8.2

## Feature
- pin kubecube to v1.8.2