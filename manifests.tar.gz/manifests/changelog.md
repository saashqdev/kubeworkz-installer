# v1.3.0

## Feature
- remove kubecube chart
- clean up useless scripts